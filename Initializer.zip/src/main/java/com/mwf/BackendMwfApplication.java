package com.mwf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendMwfApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendMwfApplication.class, args);
	}

}
