package com.mwf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendMwfApplicationTests {

	@Test
	void contextLoads() {
	}

}
